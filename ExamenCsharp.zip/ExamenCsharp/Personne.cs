﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenCsharp
{
    class Personne
    {
        private int id;
        private String nom;
        private String prenom;
        private String adresse;
        private int telephone;

        public Personne() { }

        
        public Personne(int id,String prenom,String nom,String adresse,int telephone)
        {
            this.id = id;
            this.nom = nom;
            this.prenom = prenom;
            this.adresse = adresse;
            this.telephone = telephone;
        }


        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public String Nom
        {
            get { return nom; }
            set { nom = value; }
        }

        public String Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }

        public String Adresse
        {
            get { return adresse; }
            set { adresse = value; }
        }

        public int Telephone
        {
            get { return telephone; }
            set { telephone = value; }
        }

        public virtual void AfficherInfos()
        {
            Console.WriteLine("INFORMATIONS");
            Console.WriteLine("******************");
            Console.WriteLine("ID:" + id);
            Console.WriteLine("NOM:" + nom);
            Console.WriteLine("PRENOM:" + prenom);
            Console.WriteLine("ADRESSE:" + adresse);
            Console.WriteLine("TELEPHONE:" + telephone);

        }

    }
}
