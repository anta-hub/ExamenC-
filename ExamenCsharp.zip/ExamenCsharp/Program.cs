﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenCsharp
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Permanant> l = new List<Permanant>();
            List<Vacataire> l2 = new List<Vacataire>();

            Permanant perm1 = new Permanant();
            Permanant perm2 = new Permanant();
            Permanant perm3 = new Permanant();
            Permanant perm4 = new Permanant();

            Vacataire vac1 = new Vacataire();
            Vacataire vac2 = new Vacataire();
            Vacataire vac3 = new Vacataire();
            Vacataire vac4 = new Vacataire();

            l.AddRange(new Permanant[] { perm1, perm2,perm3,perm4 });
            l2.AddRange(new Vacataire[] { vac1, vac2, vac3, vac4 });


            while (true)
            {
                Console.WriteLine("MENU PRINCIPAL");
                Console.WriteLine("1. Permanant");
                Console.WriteLine("2. Vacataire");
                Console.WriteLine("3. Quitter");

                int choix = LireEntier("Faites votre choix : ");

                switch (choix)
                {
                    case 1:
                        AfficherSousMenu1();
                        break;
                    case 2:
                        AfficherSousMenu2();
                        break;
                    case 3:
                        Console.WriteLine("Au revoir !");
                        return;
                    default:
                        Console.WriteLine("Choix invalide.");
                        break;
                }
            }
        }

        static void AfficherSousMenu1()
        {
            while (true)
            {
                Console.WriteLine("**********************");
                Console.WriteLine("******PERMANANT*******");
                Console.WriteLine("**********************");
                Console.WriteLine("1. Nouveau Permanant");
                Console.WriteLine("2. Liste Permanants ");
                Console.WriteLine("3. Retour");

                int choix = LireEntier("Faites votre choix : ");

                switch (choix)
                {
                    case 1:
                        Console.WriteLine("Vous avez choisi l'option Nouveau permanant.");
                        break;
                    case 2:
                        Console.WriteLine("Vous avez choisi l'option Liste permanant.");
                        break;
                    case 3:
                        Console.WriteLine("Retour au menu principal.");
                        return;
                    default:
                        Console.WriteLine("Choix invalide.");
                        break;
                }
            }
        }

        static void AfficherSousMenu2()
        {
            while (true)
            {
                Console.WriteLine("**********************");
                Console.WriteLine("*******VACATAIRE******");
                Console.WriteLine("**********************");
                Console.WriteLine("1. Nouveau Vacataire");
                Console.WriteLine("2. Liste Vacataires ");
                Console.WriteLine("3. Retour");

                int choix = LireEntier("Faites votre choix : ");

                switch (choix)
                {
                    case 1:
                        Console.WriteLine("Vous avez choisi l'option Nouveau vacataire.");
                        break;
                    case 2:
                        Console.WriteLine("Vous avez choisi l'option Liste vacataires.");
                        break;
                    case 3:
                        Console.WriteLine("Retour au menu principal.");
                        return;
                    default:
                        Console.WriteLine("Choix invalide.");
                        break;
                }
            }
        }

        static int LireEntier(string message)
        {
            int valeur;
            while (true)
            {
                Console.Write(message);
                if (int.TryParse(Console.ReadLine(), out valeur))
                {
                    return valeur;
                }
                Console.WriteLine("Valeur invalide.");
            }
        }
    }

}
    

