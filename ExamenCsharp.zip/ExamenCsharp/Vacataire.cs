﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenCsharp
{
    class Vacataire:Personne
    {
        public int nombreHeures;
        public float tauxHoraire;

        public Vacataire() { }

        public Vacataire(int id, string prenom, string nom, string adresse, int telephone,int nombreHeures,float tauxHoraire)
                :base(id,prenom,nom,adresse,telephone)
        {
            this.nombreHeures = nombreHeures;
            this.tauxHoraire = tauxHoraire;

        }

        public float calculerSalaire()
        {
            float sal = tauxHoraire * nombreHeures;
            return sal;
        }

        public override void AfficherInfos()
        {
            base.AfficherInfos();
            Console.WriteLine("NombreHeures : " + nombreHeures);
            Console.WriteLine("TauxHoraire : " + tauxHoraire);

        }
    }
}
