﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenCsharp
{
    class Permanant : Personne
    {
        private DateTime dateEmbauche;
        private double salaire;


        public Permanant() { }

        public Permanant(int id, string prenom, string nom, string adresse, int telephone, DateTime dateEmbauche, double salaire)
               : base(id, nom, prenom, adresse, telephone)
        {
            this.dateEmbauche = dateEmbauche;
            this.salaire = salaire;
        }
        public override void AfficherInfos()
        {
            base.AfficherInfos();
            Console.WriteLine("Date embauche : " + dateEmbauche);
            Console.WriteLine("Salaire : " + salaire);

        }
    }
}
